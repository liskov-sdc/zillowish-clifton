**To forget a device**

This example forgets device for username jane@example.com

Command::

  aws cognito-idp admin-forget-device --user-pool-id us-west-2_aaaaaaaaa --username jane@example.com --device-key us-west-2_abcd_1234-5678

