**To add a user to a group**

This example adds user Jane to group MyGroup. 

Command::

  aws cognito-idp admin-add-user-to-group --user-pool-id us-west-2_aaaaaaaaa --username Jane --group-name MyGroup
  
